# Agentic Game Pipeline · v1.0

> **Anonymous review copy of the archived v1.0 source.** The institutional gateway host is replaced with a placeholder. Set `gateway.base_url` in `machine.local.json` to a gateway implementing [docs/API.md](docs/API.md), and set `GAMECRAFTER_API_KEY` locally. The standalone Tripo client accepts `--gateway` or `GAMECRAFTER_GATEWAY_URL`. This is a packaging-only revision, not a new measured production or the latest framework release.

English | [简体中文](README.zh-CN.md)

**Turn a prompt or reference images into an editable, playable Unreal Engine demo through a coordinated agent workflow.**

The framework coordinates design and visual-review agents, Tripo, Blender, and Unreal Engine. Blender owns scene geometry, mesh preparation and rigging. UE owns animation retargeting, rendering, collision, combat and exploration. Every release passes gameplay, camera, visual and multimodal checks.

The reproducible unit is the **workflow and its contracts**, not identical generated assets. New productions start without our previous levels, characters, environment meshes or private asset library.

| Input | Playable output | Paired output |
|---|---|---|
| Text prompt; optional scene/player/Boss references | One melee Boss encounter plus a connected exploration map | RGB, metric depth, semantic IDs, skeletons, structural whitebox |
| Explicitly supplied meshes in `provided` mode | First-person, third-person and isometric / 2.5D cameras | Three cameras × combat/exploration, with shared frame timing |

**Start here:** [Quickstart](docs/QUICKSTART.md) · [Instructions for Codex](docs/CODEX.md) · [Full workflow](docs/WORKFLOW.md) · [Local interactive workflow](docs/workflow.html) · [API setup](docs/API.md)

## What is included

- An artifact-driven DAG with resumable stages, source hashes, paid-task recovery and scoped invalidation.
- Design, asset-allocation, art/layout and visual-review roles, with deterministic checks around their outputs.
- New Tripo character and environment sources; mesh cleanup, semantic bone mapping, deformation checks and 14 retargeted motion slots.
- Configurable Blender construction for terrain, roads, architecture, destinations and structural companion meshes.
- UE gameplay, Lumen/PBR lighting, anatomical facing checks, collision-aware roaming and same-session camera switching.
- Independent camera calibration and native-versus-export validation for all five channels.
- A written repair protocol for the executing coding agent. Structural failures return to the responsible stage; lighting changes do not excuse missing anatomy or broken geometry.

This is a research/prototype framework for **upright humanoids and a single melee Boss**, not a universal game generator. The output is an editable UE project with an editor-based launcher. Packaging a standalone executable is not implemented by the default provider. See [tested limits](docs/LIMITATIONS.md).

## Quick start on Windows

Install Python 3.12, Blender 5.2.1, UE 5.8 with **Templates and Feature Packs**, and Visual Studio 2022 C++ game-development tools plus a Windows SDK. These are the tested tool versions; other versions require validation. A D3D12/SM6 GPU is required for the default renderer.

```powershell
# Run from the repository root.
.\setup.ps1
& .\.venv\Scripts\python.exe pipeline.py init `
  --unreal-root "D:\UE_5.8" `
  --blender "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe" `
  --build-root "D:\GamePipelineBuilds"

# Keep the key local. Obtain it from your gateway account.
$env:GAMECRAFTER_API_KEY = "YOUR_GATEWAY_KEY"
& .\.venv\Scripts\python.exe pipeline.py doctor

& .\.venv\Scripts\python.exe pipeline.py run `
  --run-dir runs\neon_city `
  --prompt "Create a neon cyberpunk market with branching alleys, futuristic parked vehicles, a courier player and an armored humanoid Boss."
```

`init` writes `machine.local.json` and refuses to overwrite an existing configuration. Check its paths and `gateway.planner_model`; your account needs access to a vision-capable chat model, `gpt-image-2`, and `tripo3d/v3.1-20260211`. No Codex-internal image script is required. `doctor` is an offline prerequisite check, not an API or GPU benchmark.

For a reference-driven production:

```powershell
& .\.venv\Scripts\python.exe pipeline.py run `
  --run-dir runs\reference_world `
  --prompt-file examples\prompts\sakura.txt `
  --reference-scene inputs\scene.png `
  --player-image inputs\player.png `
  --boss-image inputs\boss.png
```

All three image flags are optional. Scene references guide design and image editing; character references create **new image-to-3D tasks**. Use a new run directory for each new case. To resume after a repair, omit the original prompt:

```powershell
& .\.venv\Scripts\python.exe pipeline.py run --run-dir runs\neon_city
& .\.venv\Scripts\python.exe pipeline.py play --run-dir runs\neon_city
```

The CLI automatically attempts only bounded supported lighting repairs. A source, structural, schema or gameplay failure may need Codex to inspect artifacts, edit the responsible configuration/provider and resume. [CODEX.md](docs/CODEX.md) provides a complete starter instruction.

## Fresh content and dependencies

In the default `fresh` policy, concept and character sources are new for the current run; distinctive environment sources are planned and generated as needed. Previous case catalogs, meshes, material bindings and art kits are excluded. Public matching PBR maps are selected from an extensible source menu and downloaded into this run with checksums. Engine animation templates are a software dependency, not inherited characters or levels. No UE assets, generated models or third-party texture binaries are shipped in this source package.

`provided` mode and explicit replacement/upgrade tools are available for user-requested existing assets. They are not the default for new cases or fresh-generation benchmark claims. [Asset policy](docs/ASSET_POLICY.md) explains the distinction.

## How the system fits together

```mermaid
flowchart LR
  I[Prompt + optional references] --> D[Design agent / GameSpec]
  D --> C[gpt-image-2 concept]
  C --> A[Asset demands / software allocation]
  A --> S[Public PBR acquisition]
  A --> E[Tripo environment sources]
  S --> E
  E --> P[Art + layout + exploration planning]
  D --> R[New Tripo characters / Blender cleanup + rig QA]
  P --> B[Blender detailed scene + structural whitebox]
  R --> M[UE motion retargeting]
  B --> U[UE assembly / render / gameplay]
  M --> U
  U --> V[Current-view art preflight]
  V --> T[Gameplay + camera QA]
  T --> K[Calibration + five-channel capture]
  K --> Q[Pair validation + final review]
  Q --> L[Release / replay / actual launch]
  V -. repair with new evidence .-> P
  Q -. repair responsible stage .-> U
```

The diagram shows dependencies, not a claim that all tools execute concurrently. The stage executor is sequential; independent environment-generation requests are submitted before polling so their remote work can overlap. The [full workflow](docs/WORKFLOW.md) identifies model calls, deterministic validators and executing-agent work separately.

## Repository map

```text
pipeline.py              CLI: init, doctor, plan, run, status, replay, play, timing
game_pipeline/           orchestration, contracts, gateways, source policy, validation
adapters/blender/        cleanup, rigging, construction, geometry and whitebox checks
adapters/unreal/         import, retargeting, PBR materials and integration
templates/Source/        original UE C++ gameplay, cameras, QA and capture runtime
config/                  public resource identifiers and portable configuration data
examples/                prompt files and explicit-input schema examples
tests/                   offline regression and negative-control tests
docs/                    workflow, setup, APIs, quality, data and extension guides
scripts/build_release.py allowlisted, scanned source export
runs/                    generated artifacts and journal; ignored by Git
```

## Verify and contribute

```powershell
& .\.venv\Scripts\python.exe -m unittest discover -s tests -v
& .\.venv\Scripts\python.exe pipeline.py --version
```

See [release notes](CHANGELOG.md), [validation record](docs/VALIDATION.md), [provider contracts](docs/PLUGINS.md), and [contribution rules](CONTRIBUTING.md). Tests do not require gateway calls or private demo assets. Full UE acceptance is a separate integration run.

The source is MIT licensed. Unreal Engine and its templates retain Epic's terms; public scans retain their source license; generated assets retain provider terms. See [LICENSE](LICENSE) and [third-party notices](THIRD_PARTY_NOTICES.md). The project is prepared locally for publication; no repository has been uploaded by this release process.
