# Tested scope and remaining work

v1.0 is the first public source release of the integrated workflow. It does not mean arbitrary prompts, meshes, hardware or providers succeed without intervention.

- The built-in rig supports upright humanoids with resolvable separated limbs. Fused/missing anatomy can require regeneration or source repair. Existing skins still require real deformation QA.
- Gameplay is single-player melee combat against one Boss plus exploration. Parked vehicles are environment props; driving, multiplayer, quests and inventory are not default features.
- Fourteen installed UE motions are retargeted. This is not a trained motion-generation service. First person hides the owner body; dedicated first-person arms are not authored.
- Scene construction uses configurable geometry systems, generated props and matched PBR sources. Lumen and PBR alone do not establish commercial AAA quality. Visual review and executing-agent structural revisions remain necessary.
- Output is an editable UE project and editor-based launcher. Cooking/packaging an independent executable is an extension.
- Dense multimodal semantics currently support opaque/masked surfaces. Unsupported transparency and unknown semantic IDs must not silently pass.
- Full-map traversal and sample capture are separately validated. Dataset simulation is 60 Hz; export speed is lower than real-time.
- The latest integrated cyberpunk case took about **5 h 45 min**, including failures, diagnostics, export and launch work. The 2–3 h target remains unproven. Shader-only changes can still conservatively invalidate scene dependencies.
- A transient non-Nanite VSM queue overflow was observed during one public camera switch in that case. Stable subsequent images recovered. This warning has not been proven eliminated across configurations.
- Original completed demos validate the integrated gameplay/visual/data path. The public v1.0 adds clean-source isolation, native image calls and public PBR bootstrapping. Its release tests and live public-source probes are recorded separately; they must not be described as a new full clean-machine UE game acceptance run.

Priorities: complete independent clean-machine case acceptance; tighten material dependency scopes; profile camera-switch shadow transients; expand source menus/providers with measured case-level quality; improve bounded repair convergence. Changes must retain fresh-source policy and all requested quality/data gates.
