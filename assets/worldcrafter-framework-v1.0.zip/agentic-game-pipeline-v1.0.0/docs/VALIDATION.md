# v1.0 validation record

The source release is validated separately from historical game cases. No previous demo assets are included in the public package.

- Final v1.0 source regression: 326 offline tests passed, including fresh-source isolation, native image request recovery, public PBR checksums/handoff, machine configuration, legacy policy compatibility, early input failure and cross-checkout UE project isolation.
- Live public-source probe: all 24 menu entries exposed matched 1k albedo/DirectX-normal/roughness metadata. Two sets were actually downloaded, checksummed and image-decoded without private library files or paid generation.
- A configuration pointing directly at the installed UE template resources passed the offline machine check, including all 14 motion clips and the mannequin source mesh.
- A new Python virtual environment installed the three pinned runtime dependencies successfully; `pip check` passed. A clean exported checkout passed the then-current 325-test suite without private catalogs, prior run files, benchmark images or the former image CLI. The final public directory passed all 326 tests after the project-isolation fix, using that same clean virtual environment.
- The documented offline `plan --spec --profile world_demo` path emitted 24 production stages under the fresh policy, plus the separate design bootstrap in the workflow diagram. All document links resolved, all implementation scopes resolved, and all 13 historical release manifests retained their hashes.
- Exported-package tests and final source-manifest checks are recorded in the release preparation report. Do not infer a full new game run from Python tests or source metadata checks. No paid generation was performed during source-release verification.

The earlier integrated cyberpunk production, recorded under v0.8.1, passed gameplay, valid facing negative controls, all three complete routes, 16 same-session camera cases, three calibrations, six 360-frame five-channel sequences, current visual review, replay and actual launch. Its measured hit-test average was approximately 60 FPS, with no hidden hit frames. That case took about 5 h 45 min and observed one transient VSM queue warning during camera switching.

A complete independent clean-machine v1.0 UE production remains a separate integration test. The source release does not relabel previous case acceptance as that result. See [LIMITATIONS.md](LIMITATIONS.md).
