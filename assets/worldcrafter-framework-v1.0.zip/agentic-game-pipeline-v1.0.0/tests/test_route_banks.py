import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'adapters/blender'))
from exploration import RouteField
from route_banks import offset,validate
class BankTests(unittest.TestCase):
 def setup_field(self):
  cfg={'routes':[{'id':'stream','points':[[-10,0,0],[10,0,0]],'width':3}],'route_banks':[{'center':[0,0],'radii':[12,10],'height':3,'route_ids':['stream'],'bank_width':5.5,'corridor_margin':.85}]}
  return cfg,RouteField(cfg)
 def test_corridor_and_outer_terrain_preserved(self):
  cfg,f=self.setup_field()
  for y in [-2,-1,0,1,2,10]:self.assertEqual(offset(cfg,f,0,y),0)
  self.assertGreater(offset(cfg,f,0,5),2)
 def test_bank_has_smooth_zero_boundary(self):
  cfg,f=self.setup_field();self.assertLess(offset(cfg,f,0,2.351),1e-5);self.assertLess(offset(cfg,f,0,7.849),1e-5)
 def test_invalid_bank_and_unknown_route_are_rejected(self):
  cfg,f=self.setup_field();validate(cfg)
  for key,value in [('radii',[0,10]),('bank_width',0),('route_ids',['missing'])]:
   bad={**cfg,'route_banks':[{**cfg['route_banks'][0],key:value}]}
   with self.assertRaises(ValueError):validate(bad)
 def test_nearest_parallel_route_switch_has_no_height_step(self):
  cfg={'routes':[{'id':'banked','points':[[-20,0,0],[20,0,0]],'width':3},{'id':'return','points':[[-20,10,2],[20,10,2]],'width':3}], 'route_banks':[{'center':[0,4],'radii':[18,15],'height':3,'route_ids':['banked'],'bank_width':7,'corridor_margin':.85}]}
  f=RouteField(cfg);a=offset(cfg,f,0,4.999);b=offset(cfg,f,0,5.001)
  self.assertGreater(min(a,b),1)
  self.assertLess(abs(a-b),.01)
  for y in [9,10,11]:self.assertEqual(offset(cfg,f,0,y),0)
