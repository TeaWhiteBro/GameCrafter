import math,unittest
from adapters.blender.terrain_lod import refine

class TerrainLodTests(unittest.TestCase):
    def test_curved_surface_refines_without_relaxing_error(self):
        extent=10
        height=lambda x,y:.4*(x*x+y*y)
        points=[(-4.7+i*.31,-4.8+j*.37) for i in range(30) for j in range(26)]
        def evaluate(vs,fs):
            n=round(math.sqrt(len(vs)))-1;step=extent/n;errors=[]
            for x,y in points:
                a=(x+extent/2)/step;b=(y+extent/2)/step;i=int(a);j=int(b);u=a-i;v=b-j
                z00=vs[j*(n+1)+i][2];z10=vs[j*(n+1)+i+1][2];z01=vs[(j+1)*(n+1)+i][2];z11=vs[(j+1)*(n+1)+i+1][2]
                z=z00*(1-u-v)+z10*u+z01*v if u+v<=1 else z11*(u+v-1)+z10*(1-v)+z01*(1-u)
                errors.append(abs(z-height(x,y)))
            return errors
        _,_,audit=refine(extent,2,.5,height,evaluate)
        self.assertTrue(audit['passed']);self.assertGreater(len(audit['attempts']),1)
        self.assertGreater(audit['attempts'][0]['p95_error_m'],.18);self.assertLessEqual(audit['p95_error_m'],.18)
    def test_exhausted_refinement_stays_failed(self):
        _,_,audit=refine(5,1,.5,lambda x,y:0,lambda vs,fs:[.3]*100)
        self.assertFalse(audit['passed']);self.assertEqual(audit['attempts'][-1]['step_m'],.5)
    def test_missing_or_nonfinite_probes_cannot_pass(self):
        for values in [[],[float('nan')]]:
            with self.assertRaises(ValueError):refine(5,1,.5,lambda x,y:0,lambda vs,fs:values)

if __name__=='__main__':unittest.main()
