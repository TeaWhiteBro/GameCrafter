import random,sys,unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'adapters/blender'))
from modular_paving import cells,patch,difference,uncovered

def area(poly):
    return abs(sum(a[0]*b[1]-a[1]*b[0] for a,b in zip(poly,list(poly[1:])+[poly[0]])))/2

def contains(poly,point):
    turns=[np.cross(np.asarray(b)-a,np.asarray(point)-a) for a,b in zip(poly,list(poly[1:])+[poly[0]])]
    return all(t>1e-7 for t in turns) or all(t<-1e-7 for t in turns)

class ModularPavingTests(unittest.TestCase):
    def test_difference_has_exact_area_for_both_windings(self):
        subject=[[0,0],[10,0],[10,10],[0,10]];excluded=[[2,2],[8,2],[8,8],[2,8]]
        for a in [subject,subject[::-1]]:
            for b in [excluded,excluded[::-1]]:
                pieces=difference(a,b)
                self.assertAlmostEqual(sum(map(area,pieces)),64)
                self.assertTrue(all(area(p)>1e-10 for p in pieces))
        self.assertEqual(difference(subject,subject),[])
        self.assertAlmostEqual(sum(map(area,difference(subject,[[10,0],[12,0],[12,10],[10,10]]))),100)

    def test_crossing_routes_have_one_surface_owner_and_no_gaps(self):
        shapes=[[[0,0],[6,0],[6,6],[0,6]], [[-2,2],[9,2],[9,4],[-2,4]], [[2,-2],[4,-2],[4,9],[2,9]]]
        occupied=[];pieces=[]
        for shape in shapes:
            pieces.extend(uncovered(shape,occupied));occupied.append(shape)
        self.assertAlmostEqual(sum(map(area,pieces)),56)
        for x in np.arange(-1.87,9,.31):
            for y in np.arange(-1.79,9,.29):
                expected=any(contains(s,(x,y)) for s in shapes)
                self.assertEqual(sum(contains(p,(x,y)) for p in pieces),int(expected))

    def test_clipped_cells_cover_actual_convex_footprints_without_holes(self):
        for shape in [[[-8,0],[8,0],[8,16],[-8,16]],[[-1,-1],[3,2],[2,4],[-2,1]]]:
            expected=abs(sum(np.cross(shape[i],shape[(i+1)%len(shape)]) for i in range(len(shape))))/2
            polygons=list(cells(shape,(1.2,.6),0))
            area=sum(abs(sum(np.cross(p[i],p[(i+1)%len(p)]) for i in range(len(p))))/2 for p in polygons)
            self.assertAlmostEqual(area,expected,places=6)
            reverse=list(cells(shape[::-1],(1.2,.6),0))
            self.assertEqual(len(polygons),len(reverse))

    def test_sloped_stone_has_planar_crown_and_continuous_shallow_bedding(self):
        emitted=[]
        def mesh(name,vs,fs,mat,**kwargs):emitted.append((name,np.array(vs),fs));return None
        api={'height':lambda x,y:.13*x+.07*y,'mesh':mesh,'finish_stone':lambda ob,b:None,'rng':random.Random(2)}
        patch(api,[[-1,-1],[2,-1],[2,2],[-1,2]],'stone')
        for name,vs,fs in emitted:
            surface=vs if 'support' in name else vs[len(vs)//2:]
            offset=.037 if 'support' in name else .045
            self.assertLess(np.max(np.abs(surface[:,2]-(surface[:,0]*.13+surface[:,1]*.07+offset))),1e-8)
        self.assertTrue(any('support' in n for n,_,_ in emitted))

    def test_joint_removal_is_bounded_instead_of_missing_random_slabs(self):
        outline=[[0,0],[12,0],[12,6],[0,6]]
        area=sum(abs(sum(np.cross(p[i],p[(i+1)%len(p)]) for i in range(len(p))))/2 for p in cells(outline))
        self.assertGreater(area/72,.97)
        self.assertLess(area,72)

if __name__=='__main__':unittest.main()
