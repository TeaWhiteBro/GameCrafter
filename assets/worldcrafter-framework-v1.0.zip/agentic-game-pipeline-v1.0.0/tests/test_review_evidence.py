import tempfile,unittest
from pathlib import Path
from game_pipeline.core import write_json,digest,StageError
from game_pipeline.review_evidence import geometry_evidence,diagnostic_views

class EvidenceTests(unittest.TestCase):
    def test_stale_geometry_diagnostic_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);blend=root/'scene.blend';blend.write_bytes(b'geometry-v1')
            report=root/'report.json';write_json(report,{'blend':str(blend)})
            audit=root/'audit.json';write_json(audit,{'source_report_sha256':digest(report),'source_blend_sha256':digest(blend),'components':[]})
            self.assertEqual(geometry_evidence([audit],report)[0]['audit']['components'],0)
            blend.write_bytes(b'geometry-v2')
            with self.assertRaisesRegex(StageError,'outdated'):geometry_evidence([audit],report)

    def test_diagnostic_images_need_current_source_and_unchanged_pixels(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);blend=root/'scene.blend';blend.write_bytes(b'geometry-v1')
            report=root/'report.json';write_json(report,{'blend':str(blend)})
            image=root/'side.png';image.write_bytes(b'fixture-image')
            audit=root/'audit.json'
            record={'source_report_sha256':digest(report),'source_blend_sha256':digest(blend),
                    'images':[{'path':str(image),'sha256':digest(image),'evidence_type':'blender_geometry_diagnostic','caption':'Side view; vegetation hidden.'}]}
            write_json(audit,record)
            self.assertEqual(diagnostic_views([audit],report)[0]['path'],str(image))
            image.write_bytes(b'changed-pixels')
            with self.assertRaisesRegex(StageError,'changed or is missing'):diagnostic_views([audit],report)
            record['images'][0]['sha256']=digest(image);write_json(audit,record)
            blend.write_bytes(b'different-geometry')
            with self.assertRaisesRegex(StageError,'outdated'):diagnostic_views([audit],report)

    def test_diagnostic_cannot_be_mislabelled_as_normal_runtime_art(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);blend=root/'scene.blend';blend.write_bytes(b'geometry')
            report=root/'report.json';write_json(report,{'blend':str(blend)})
            image=root/'side.png';image.write_bytes(b'image');audit=root/'audit.json'
            record={'source_report_sha256':digest(report),'source_blend_sha256':digest(blend),
                    'images':[{'path':str(image),'sha256':digest(image),'evidence_type':'approved_runtime','caption':'A side view'}]}
            write_json(audit,record)
            with self.assertRaisesRegex(StageError,'renderer/scope'):diagnostic_views([audit],report)
