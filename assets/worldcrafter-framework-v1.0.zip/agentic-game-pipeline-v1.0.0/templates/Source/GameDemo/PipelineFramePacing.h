#pragma once

// Retain UE's requested timer precision for this game process when occluded.
void ConfigurePipelineFramePacing();
