param([string]$Python = 'python')
$ErrorActionPreference = 'Stop'
& $Python -m venv (Join-Path $PSScriptRoot '.venv')
if ($LASTEXITCODE) { exit $LASTEXITCODE }
$pipelinePython = Join-Path $PSScriptRoot '.venv/Scripts/python.exe'
& $pipelinePython -m pip install -r (Join-Path $PSScriptRoot 'requirements.lock.txt')
if ($LASTEXITCODE) { exit $LASTEXITCODE }
Write-Output 'Dependencies installed. Run pipeline.py init with your UE and Blender paths, then pipeline.py doctor.'
