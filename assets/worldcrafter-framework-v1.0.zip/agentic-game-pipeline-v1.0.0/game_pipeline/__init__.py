"""Pluggable, artifact-driven game production pipeline."""
__version__ = '1.0.0'
