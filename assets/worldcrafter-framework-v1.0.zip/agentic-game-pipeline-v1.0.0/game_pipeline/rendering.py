"""Shared runtime rendering policy for play, QA, and paired capture."""

def profile():
    # Refresh shadows of coarse Nanite pages when finer geometry streams in.
    # Dense area-preserving foliage shares residency with buildings. The 1 GiB
    # pool was verified on an 8 GiB GPU; it is not a universal performance target.
    return {'version': 3, 'orthographic_short_range_ao': 'disabled_per_view_gameplay_and_capture', 'console_variables': {
        'r.Nanite.VSMInvalidateOnLODDelta': 1,
        'r.Nanite.Streaming.StreamingPoolSize': 1024,
    }}


def launch_args():
    variables = profile()['console_variables']
    return ['-ExecCmds=' + ','.join(f'{key} {value}' for key, value in variables.items())]
