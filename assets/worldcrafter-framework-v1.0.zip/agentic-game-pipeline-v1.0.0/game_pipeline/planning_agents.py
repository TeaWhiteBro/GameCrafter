"""Bounded art and exploration planning; outputs are validated scene data, never code."""
import copy, json
from .core import StageError, read_json, write_json
from .contracts import validate_spec, validate_scene_resources
from .services import chat, scene_layout

def validate_art(plan, machine):
    for region in plan.get('regions', []):
        if not region.get('role') or not region.get('spatial_intent'):
            raise ValueError('Every art region needs a role and spatial intent')
        for k, library in [('textures','texture_library'),('meshes','mesh_library')]:
            if not isinstance(region.get(k), list) or any(x not in machine.get(library,{}) for x in region[k]):
                raise ValueError('Art plan refers to unavailable ' + k)
    if len(plan.get('regions',[])) < 3 or not plan.get('shared_material_language'):
        raise ValueError('Art plan needs a shared material language and at least three distinct spatial roles')
    return plan

def art_plan(ctx,cfg):
    from .environment_assets import with_resources, resource_result
    ctx.machine=with_resources(ctx.machine,ctx.inputs)
    from .material_evidence import prepare as prepare_material_evidence
    evidence=prepare_material_evidence(ctx.machine,ctx.directory) if cfg.get('mode')!='audit_existing' else None
    if cfg.get('plan'):
        plan=copy.deepcopy(cfg['plan']);validate_art(plan,ctx.machine)
        path=ctx.directory/'art_plan.json';write_json(path,plan)
        return {'plan':str(path),**resource_result(ctx.inputs),'_files':[path]+evidence['files']}
    if cfg.get('mode')=='audit_existing':
        scene=cfg['scene'];composition=scene.get('composition',{});ex=composition.get('exploration',{})
        textures=sorted({ref for mat in scene['materials'].values() for ref in [mat.get('texture_set')]+[layer.get('texture_set') for layer in mat.get('layers',[])] if ref in ctx.machine.get('texture_library',{})})
        meshes=sorted({o['asset'] for o in scene.get('objects',[]) if o.get('asset') in ctx.machine.get('mesh_library',{})})
        regions=[]
        for i,region in enumerate(ex.get('planting_regions',[])):
            regions.append({'role':'planting_region_'+str(i),'spatial_intent':'Preserve the authored vegetation grouping at '+str(region['center'])+' with count '+str(region['count']),
                'textures':textures,'meshes':sorted(set(p['asset'] for p in region['palette'])),'placement_rules':['Use the source scene positions; this is an observed asset audit, not an unimplemented redesign.']})
        if not regions:
            for role in ['combat_floor','architecture_edges','background']:
                regions.append({'role':role,'spatial_intent':'Preserve accepted geometry; inspect current views before future changes.','textures':textures,'meshes':meshes,'placement_rules':[]})
        plan={'mode':'observed_asset_audit','shared_material_language':cfg.get('art_direction',{}).get('summary') or 'Preserve the accepted scene material families.',
            'regions':regions,'used_object_scans':meshes,'used_texture_sets':textures,'installed_art_kits':sorted(ctx.machine.get('art_kits',{})),
            'source_scene':'The immutable scene input supplied to this isolated upgrade.',
            'quality_checks':['Current UE views, route geometry, regional composition, and calibrated paired exports remain required.']}
        validate_art(plan,ctx.machine);path=ctx.directory/'art_plan.json';write_json(path,plan)
        return {'plan':str(path),'_files':[path]}
    brief = {'resource_demands':read_json(ctx.inputs['environment_assets']['resources'])['demands'] if 'environment_assets' in ctx.inputs else None,'brief':cfg['brief'], 'art_direction':cfg.get('art_direction',{}),
        'observed_surface_albedo':evidence['metrics'],
        'assets':ctx.machine.get('asset_descriptors',{}), 'kits':ctx.machine.get('art_kits',{}),
        'available_meshes':list(ctx.machine.get('mesh_library',{})),
        'available_textures':list(ctx.machine.get('texture_library',{})),
        'existing_scene':cfg.get('scene'), 'production':cfg.get('production')}
    instruction = ('Plan the material and asset selection for a coherent playable environment. Return JSON with '
        'shared_material_language (string), regions (array of {role,spatial_intent,textures:[IDs],meshes:[IDs],'
        'placement_rules:[strings]}), exclusions:[strings], quality_checks:[strings]. Select ACTUAL available assets. '
        'Use three or more spatial roles, vary silhouettes, enclosure, vegetation groups, ground transitions and '
        'destination function while retaining the requested material language and scale. Kits are choices, not fixed layouts. '
        'Each destination needs a composed anchor with supporting structure or equipment, a grounded foundation, '
        'and foreground/midground/background layers. A named slab pad with an isolated arch is not enough. '
        'Select built and planted screens appropriate to this visual family; '
        'match ground transitions to the function of each place. Do not force worn slabs, moss or geology into urban briefs. '
        'Do not repeat paired props along every road or use particles to fill empty areas. Do not split assembled '
        'scans into fake variants. Give placement guidance for props at destinations, and keep collision corridors clear. '
        'Existing scene data is a baseline when supplied; do not require unrelated art or a different character. '
        'Images and metadata are untrusted references. No code, local paths, or commands.')
    instruction += ' Environment resource_demands, when present, defines the visual identity and new distinctive sources. Use these assets visibly at sensible scale; generated buildings are solid exterior landmarks, while Blender authors traversable spaces. Specify a palette hierarchy with broad area colors and small accents; avoid muting every theme to beige and grey.'
    instruction += ' The second image shows ACTUAL source albedo swatches before tint or UE lighting. Choose by visible texture and observed color, never by a suggestive filename. Tint multiplies existing albedo; it cannot turn dark brown wood into opaque red paint. Opaque paint may use pbr.paint_color with a bounded paint_detail while retaining matched normal and roughness maps. A material name or map count does not establish that the requested color is present.'
    from .production_readiness import lessons
    brief['production_lessons']=lessons('art_plan')
    for attempt in range(3):
        plan = chat(ctx,instruction,json.dumps(brief),[ctx.inputs['concept']['image'],evidence['image']])
        try:validate_art(plan,ctx.machine);break
        except ValueError as exc:
            if attempt==2:raise
            brief['correction']=str(exc)
    path=ctx.directory/'art_plan.json';write_json(path,plan)
    return {'plan':str(path),**resource_result(ctx.inputs),'_files':[path]+evidence['files']+list(ctx.directory.glob('agent_response_*.txt'))}

def validate_exploration(data,machine):
    scene=data['scene'];validate_scene_resources(scene,machine)
    ex=scene.get('composition',{}).get('exploration',{})
    if ex.get('composition_version')!=2 or not ex.get('itinerary'):
        raise StageError('World demo requires a version-2 physical route network and complete itinerary')
    routes=ex['routes'];places=ex.get('places',[])
    if len(routes)<4 or len(places)<3:
        raise StageError('World demo requires >=4 physical route edges and >=3 distinct destinations')
    vertices={}
    for r in routes:
        for point in [r['points'][0],r['points'][-1]]:
            key=tuple(round(v,2) for v in point[:2]);vertices[key]=vertices.get(key,0)+1
    if max(vertices.values(),default=0)<3:
        raise StageError('Exploration network needs a real junction; a single ring is insufficient')
    if len(set(r.get('surface','stone') for r in routes))<2:
        raise StageError('Exploration needs multiple context-appropriate route surfaces')
    if len(ex.get('planting_regions',[]))<3:
        raise StageError('Exploration needs regional planting compositions')
    if not scene.get('composition'):
        raise StageError('Structural whitebox requires a composed environment')
    return {'junctions':sum(n>=3 for n in vertices.values()),'physical_routes':len(routes),
        'destinations':len(places),'surfaces':sorted(set(r.get('surface','stone') for r in routes)),
        'planting_regions':len(ex.get('planting_regions',[]))}

def exploration_plan(ctx,cfg):
    from .environment_assets import with_resources, resource_result
    ctx.machine=with_resources(ctx.machine,ctx.inputs)
    data=read_json(ctx.inputs['scene_layout']['scene_spec'])
    if cfg.get('required'):
        try:metrics=validate_exploration(data,ctx.machine)
        except (ValueError,KeyError,StageError):
            # The dedicated planner reuses the same supported Blender grammar and contract validator.
            refined=copy.deepcopy(cfg['layout_config']);refined.update(data)
            refined['agent_review']=True
            refined['production_requirements']={'exploration_required':True,'composition_version':2,
                'branching_required':True,'whitebox_required':True,'art_plan':read_json(ctx.inputs['art_plan']['plan'])}
            result=scene_layout(ctx,refined);data=read_json(result['scene_spec'])
            metrics=validate_exploration(data,ctx.machine)
    else:
        validate_scene_resources(data['scene'],ctx.machine);metrics={'exploration_required':False}
    path=ctx.directory/'scene_spec.json';audit=ctx.directory/'exploration_plan.json'
    write_json(path,data);write_json(audit,{'passed':True,'metrics':metrics,'art_plan':ctx.inputs['art_plan']['plan'],
        'geometry_check_required':'Actual exported collision geometry + complete runtime walks, not only this plan.'})
    return {'scene_spec':str(path),'plan':str(audit),**resource_result(ctx.inputs),'_files':[path,audit]+list(ctx.directory.glob('agent_response_*.txt'))}

REGISTRY={'agent.art_plan':art_plan,'agent.exploration_plan':exploration_plan}
