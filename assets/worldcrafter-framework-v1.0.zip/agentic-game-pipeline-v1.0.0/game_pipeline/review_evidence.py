"""Verify optional geometric diagnostics before showing them to a visual reviewer."""
from pathlib import Path
from .core import read_json,digest,StageError

def geometry_evidence(paths,scene_report):
    scene=read_json(scene_report);result=[]
    for path in paths:
        audit=read_json(path)
        if audit.get('source_report_sha256')!=digest(scene_report) or audit.get('source_blend_sha256')!=digest(scene['blend']):
            raise StageError('Geometry review evidence refers to an outdated scene: '+str(path))
        # The complete diagnostic remains a hashed stage artifact. Keep the
        # review payload bounded while retaining the worst support cases.
        summary=audit
        if 'components' in audit:
            components=audit['components']
            summary={k:v for k,v in audit.items() if k!='components'}
            summary.update(components=len(components),detached_components=sum(r.get('whole_piece_detached',False) for r in components),
                largest_undercuts=sorted(components,key=lambda r:r.get('max_bottom_gap_m',0),reverse=True)[:8])
        result.append({'file':Path(path).name,'audit':summary,
            'scope':'Measured geometric support; does not establish artistic quality or waive current visual defects.'})
    return result


def diagnostic_views(paths,scene_report):
    """Additional views resolve occluded geometry without replacing runtime art."""
    geometry_evidence(paths,scene_report)
    result=[]
    for path in paths:
        audit=read_json(path)
        for image in audit.get('images',[]):
            if image.get('evidence_type') not in ('blender_geometry_diagnostic','ue_geometry_diagnostic') or not image.get('caption'):
                raise StageError('Geometry diagnostic image needs an explicit renderer/scope and caption')
            file=Path(image.get('path',''))
            if not file.is_file() or digest(file)!=image.get('sha256'):
                raise StageError('Geometry diagnostic image changed or is missing: '+str(file))
            result.append({'path':str(file),'caption':image['caption'],'evidence_type':image['evidence_type']})
    if len(result)>12:raise StageError('Keep supplementary geometry diagnostics bounded to twelve views')
    return result
