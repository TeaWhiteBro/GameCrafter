# Agentic Game Pipeline · v1.0

[English](README.md) | 简体中文

**通过多 Agent 协同工作流，将 prompt 或参考图转化为可编辑、可游玩的 Unreal Engine 游戏 demo。**

框架协调设计与视觉评审 Agent、Tripo、Blender 和 Unreal Engine，让各自负责擅长的工作。Blender 负责场景几何、网格处理和骨骼绑定；UE 负责动画重定向、渲染、碰撞、战斗与漫游。每次发布都必须通过玩法、相机、视觉及多模态验收。

我们要求可复现的是**工作流及其输入输出契约**，而非完全相同的生成资产。新案例从零开始，不依赖之前的关卡、角色、环境模型或私有美术资产库。

本文与 [英文 README](README.md) 对应，命令、代码和 prompt 示例保留英文；链接中的详细指南目前以英文提供。

| 输入 | 可玩产物 | 配对输出 |
|---|---|---|
| 文本 prompt；可选的场景、玩家及 Boss 参考图 | 一个近战 Boss 遭遇战，以及与之连通的漫游地图 | RGB、米制深度、语义 ID、骨骼、结构白模 |
| 在 `provided` 模式下显式提供的模型 | 第一人称、第三人称及等距／2.5D 视角 | 三种视角 × 战斗／漫游，各通道共享帧时序 |

**从这里开始：**[快速上手](docs/QUICKSTART.md) · [如何让 Codex 执行](docs/CODEX.md) · [完整工作流](docs/WORKFLOW.md) · [本地交互式流程图](docs/workflow.html) · [API 配置](docs/API.md)

## 包含哪些能力

- 以产物为依据的有向无环图（DAG）：支持阶段续跑、源文件哈希、付费任务恢复，以及仅使受影响阶段失效的依赖管理。
- 设计、资产分工、美术与布局规划、视觉评审等职责；各 Agent 的输出由确定性程序检查。
- 通过 Tripo 生成新的角色与环境资产；执行网格清理、语义骨骼映射、变形检查，并重定向 14 个动作槽位。
- 在 Blender 中按配置构建地形、道路、建筑、漫游目的地及对应的结构白模。
- UE 玩法、Lumen／PBR 光照、基于角色骨骼的朝向检查、保留真实碰撞的漫游，以及同一局内的视角切换。
- 独立的相机标定，以及全部五通道的原始数据与导出结果对照验证。
- 面向执行代码 Agent 的明确纠错协议：结构问题返回对应阶段修复；不能用调整光照来绕过缺失肢体或错误几何。

这是面向**直立人形角色与单个近战 Boss**的研究／原型框架，并非适用于任意游戏的生成器。产物是可编辑的 UE 工程与基于编辑器的游戏启动器；默认适配器尚未实现独立可执行文件的打包。详见[已验证范围与限制](docs/LIMITATIONS.md)。

## Windows 快速上手

安装 Python 3.12、Blender 5.2.1、UE 5.8（包含 **Templates and Feature Packs**），以及 Visual Studio 2022 的 C++ 游戏开发工具和 Windows SDK。这些是已测试的工具版本，其他版本需要另行验证。默认渲染器要求显卡支持 D3D12／SM6。

```powershell
# Run from the repository root.
.\setup.ps1
& .\.venv\Scripts\python.exe pipeline.py init `
  --unreal-root "D:\UE_5.8" `
  --blender "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe" `
  --build-root "D:\GamePipelineBuilds"

# Keep the key local. Obtain it from your gateway account.
$env:LEVELINFINITE_API_KEY = "YOUR_GATEWAY_KEY"
& .\.venv\Scripts\python.exe pipeline.py doctor

& .\.venv\Scripts\python.exe pipeline.py run `
  --run-dir runs\neon_city `
  --prompt "Create a neon cyberpunk market with branching alleys, futuristic parked vehicles, a courier player and an armored humanoid Boss."
```

`init` 会写入 `machine.local.json`，并拒绝覆盖已有配置。请检查其中的路径和 `gateway.planner_model`；你的网关账号需要能访问支持视觉输入的对话模型、`gpt-image-2` 和 `tripo3d/v3.1-20260211`。流程不依赖 Codex 内部的图像生成脚本。`doctor` 只检查本机前置条件，不验证 API 的实际可用性，也不进行 GPU 性能测试。

使用参考图生成：

```powershell
& .\.venv\Scripts\python.exe pipeline.py run `
  --run-dir runs\reference_world `
  --prompt-file examples\prompts\sakura.txt `
  --reference-scene inputs\scene.png `
  --player-image inputs\player.png `
  --boss-image inputs\boss.png
```

三个参考图参数均为可选项。场景参考图用于指导设计和图像编辑；角色参考图会创建**新的图生 3D 任务**。每个新案例应使用新的运行目录。修复后续跑时，省略原始 prompt：

```powershell
& .\.venv\Scripts\python.exe pipeline.py run --run-dir runs\neon_city
& .\.venv\Scripts\python.exe pipeline.py play --run-dir runs\neon_city
```

CLI 只会自动尝试受支持、数值范围受限的光照修复。源资产、结构、数据契约或玩法出现问题时，可能需要 Codex 检查产物，修改对应配置或适配器，再继续执行。[CODEX.md](docs/CODEX.md) 提供了可以直接使用的完整任务指令。

## 从零生成与外部依赖

默认 `fresh` 策略会为本次运行生成新的概念图与角色，并按需求规划、生成具有场景辨识度的环境资产。之前案例的资源目录、模型、材质绑定和美术组合不会被带入。配套 PBR 贴图从可扩展的公开资源清单中选择，下载到本次运行目录，并记录校验值。引擎动画模板属于明确声明的软件依赖，不代表继承旧案例的角色或关卡。源码包中不包含 UE 资产、生成模型或第三方贴图文件。

如果用户明确要求使用已有资产，可以选择 `provided` 模式或显式的替换／升级工具。这些操作不是新案例的默认流程，也不能作为从零生成的 benchmark 结果。详见[资产策略](docs/ASSET_POLICY.md)。

## 整个系统如何协同

```mermaid
flowchart LR
  I[Prompt + optional references] --> D[Design agent / GameSpec]
  D --> C[gpt-image-2 concept]
  C --> A[Asset demands / software allocation]
  A --> S[Public PBR acquisition]
  A --> E[Tripo environment sources]
  S --> E
  E --> P[Art + layout + exploration planning]
  D --> R[New Tripo characters / Blender cleanup + rig QA]
  P --> B[Blender detailed scene + structural whitebox]
  R --> M[UE motion retargeting]
  B --> U[UE assembly / render / gameplay]
  M --> U
  U --> V[Current-view art preflight]
  V --> T[Gameplay + camera QA]
  T --> K[Calibration + five-channel capture]
  K --> Q[Pair validation + final review]
  Q --> L[Release / replay / actual launch]
  V -. repair with new evidence .-> P
  Q -. repair responsible stage .-> U
```

图中表达的是依赖关系，不表示所有工具同时执行。当前阶段执行器按顺序运行；独立的环境生成请求会先提交再轮询，因此它们在远端的生成工作可以重叠。[完整工作流](docs/WORKFLOW.md) 区分了模型调用、确定性验证程序，以及执行 Agent 的具体工作。

## 代码目录

```text
pipeline.py              CLI: init, doctor, plan, run, status, replay, play, timing
game_pipeline/           orchestration, contracts, gateways, source policy, validation
adapters/blender/        cleanup, rigging, construction, geometry and whitebox checks
adapters/unreal/         import, retargeting, PBR materials and integration
templates/Source/        original UE C++ gameplay, cameras, QA and capture runtime
config/                  public resource identifiers and portable configuration data
examples/                prompt files and explicit-input schema examples
tests/                   offline regression and negative-control tests
docs/                    workflow, setup, APIs, quality, data and extension guides
scripts/build_release.py allowlisted, scanned source export
runs/                    generated artifacts and journal; ignored by Git
```

## 验证与贡献

```powershell
& .\.venv\Scripts\python.exe -m unittest discover -s tests -v
& .\.venv\Scripts\python.exe pipeline.py --version
```

详见[版本记录](CHANGELOG.md)、[验证记录](docs/VALIDATION.md)、[适配器契约](docs/PLUGINS.md)和[贡献规范](CONTRIBUTING.md)。离线测试不需要调用网关，也不依赖私有 demo 资产；完整 UE 验收属于单独的集成运行。

源码采用 MIT 许可证。Unreal Engine 及其模板继续适用 Epic 的条款；公开扫描资产保留各自的来源许可证；生成资产适用对应服务商的条款。详见 [LICENSE](LICENSE) 和[第三方声明](THIRD_PARTY_NOTICES.md)。项目目前已在本地整理为可发布的源码包，本次发布准备流程尚未将仓库上传到远端。
