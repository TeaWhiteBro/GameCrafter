# Changelog

## 1.0.0 — 2026-09-18

First public-source packaging of the integrated agentic game workflow, based on the v0.8.1 production line. Historical demo manifests retain their recorded versions.

### Public operation

- New default `fresh` source policy clears previous-case catalogs and asset bindings and rejects existing mesh tasks/inheritance. Explicit `provided` mode retains user-input and replacement workflows.
- New `surface_assets` stage downloads selected matched public PBR maps into each run; source identities, licenses and checksums are recorded and handed through planning, Blender and UE.
- Native `gpt-image-2` generation/edit adapter replaces the private Codex image-script dependency. Saved responses and uncertain-POST markers support recovery without repeated charges.
- Machine `init` and `doctor`; complete engine motion-dependency checks before paid runs; config-relative tool paths; prompt files; non-overwriting new-run guard.
- UE project namespaces include the full run identity, so matching folder names in separate checkouts cannot overwrite each other's builds.
- English README, setup/API/Codex instructions, full system workflow, contracts, limitations and clean-source export tooling.
- MIT source license and explicit separation of UE, public scans, provider assets and code licensing.

### Consolidated production lessons

The already-tested production line includes urban frontage, graphics, ramps and roof-service construction; authored single-sided winding; shared detail/whitebox transforms; functional material zones; final-UE material coordinate checks; default and switched projection/AO policy; and correctly targeted destination diagnostics. These join the existing mesh-cleanup/deformation, facing, collision, multi-camera and five-channel acceptance requirements.

### Compatibility and remaining work

Explicit v0.7.0, v0.8.0 and v0.8.1 production policies remain accepted without rewriting historical release files. Resuming an older run with changed implementations may invalidate affected stages; this is distinct from launching its already-released project.

The latest integrated cyberpunk case took approximately 5 h 45 min. A 2–3 h guarantee, shader-only dependency isolation and universal absence of transient VSM warnings are not claimed. Public adapter and clean-export tests are separate from a new full clean-machine gameplay acceptance run; see docs/VALIDATION.md.

## Earlier development

- v0.8.1: production lessons, readiness checks, timing, review memory and source-verified preflight reuse.
- v0.8: asset demands, Tripo environment resources and visual-family planning before layout.
- v0.7: exploration, same-session three-camera QA, calibrated five-channel collection and pair validation on the release DAG.
- v0.6: structural whitebox geometry and articulated capsules.
- v0.5: camera modes, public art resources and multimodal capture.
- v0.4: source/rig/facing acceptance and explicit reference-based character replacement.

Earlier demonstration assets and private run evidence are deliberately excluded from the public source distribution.
