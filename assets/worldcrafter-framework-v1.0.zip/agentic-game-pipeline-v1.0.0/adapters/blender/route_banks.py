"""Smooth terrain banks around configured route sections, preserving corridors."""
import math
def validate(config):
    ids={r.get('id') for r in config.get('routes',[])}
    for b in config.get('route_banks',[]):
        for key in ['center','radii']:
            if len(b.get(key,[]))!=2 or any(not isinstance(v,(float,int)) or not math.isfinite(v) for v in b[key]):raise ValueError('Banks require finite XY '+key)
        if any(v<2 or v>40 for v in b['radii']):raise ValueError('Bank radii must be 2-40m')
        if not .1<=b.get('height',0)<=10 or not 1.5<=b.get('bank_width',5.5)<=12:raise ValueError('Bank height or width outside supported range')
        if not .5<=b.get('corridor_margin',.85)<=3:raise ValueError('Bank corridor margin outside supported range')
        if not b.get('route_ids') or not set(b['route_ids'])<=ids:raise ValueError('Bank references unknown routes')
def offset(config,field,x,y):
    total=0.
    for bank in config.get('route_banks',[]):
        cx,cy=bank['center'];rx,ry=bank['radii'];q=((x-cx)/rx)**2+((y-cy)/ry)**2
        if q>=1:continue
        distance,z,width,index=field.query(x,y,bank['route_ids'])
        if index<0:continue
        clear=width*.5+bank.get('corridor_margin',.85);t=(distance-clear)/bank.get('bank_width',5.5)
        if not 0<t<1:continue
        taper=min(1,(1-q)*3);taper=taper*taper*(3-2*taper)
        # Query the selected route independently. A nearest-route identity
        # switch must not turn a nonzero bank into a vertical construction seam.
        all_distance,_,all_width,_=field.query(x,y)
        safety=max(0,min(1,(all_distance-all_width*.5-bank.get('corridor_margin',.85))/1.5))
        safety=safety*safety*(3-2*safety)
        total+=bank['height']*math.sin(math.pi*t)**2*taper*safety*(.90+.10*math.sin(x*.53+y*.71))
    return total
