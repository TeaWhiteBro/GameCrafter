"""Measured albedo-region edits; preserve spatial texture/UV detail and independent PBR controls."""
import numpy as np
from mathutils import Vector

def hsv(rgb):
    high=rgb.max(-1);low=rgb.min(-1);delta=high-low;den=np.maximum(delta,1e-8);h=np.zeros_like(high)
    for channel,expr in [(0,((rgb[...,1]-rgb[...,2])/den)%6),(1,(rgb[...,2]-rgb[...,0])/den+2),(2,(rgb[...,0]-rgb[...,1])/den+4)]:
        h=np.where((rgb.argmax(-1)==channel)&(delta>1e-8),expr*60,h)
    return np.stack([h,np.where(high>1e-8,delta/np.maximum(high,1e-8),0),high],-1)

def refine(ob,rules,image):
    pixels=np.asarray(image.pixels[:],dtype=np.float32).reshape(image.size[1],image.size[0],4)
    original=pixels.copy();values=hsv(original[...,:3]);label=np.zeros(pixels.shape[:2],dtype=np.int16);audit=[]
    for i,rule in enumerate(rules,1):
        limits=rule['hsv_range'];mask=np.ones(pixels.shape[:2],bool)
        for axis,(low,high) in enumerate(limits):mask &= (values[...,axis]>=low)&(values[...,axis]<=high)
        mask &= label==0;label[mask]=i
        pixels[mask,:3]=np.clip(original[mask,:3]*np.asarray(rule['rgb_multiplier']),0,1)
        audit.append({'region':rule['name'],'selected_pixels':int(mask.sum()),'fraction':float(mask.mean()),'operation':rule})
        if not mask.any():raise ValueError('Texture region selected no pixels: '+rule['name'])
    image.pixels.foreach_set(pixels.ravel());image.update()
    original_mat=ob.data.materials[0];indices=[0]
    for rule in rules:
        if rule.get('split_material',True) is False:
            indices.append(0);continue
        mat=original_mat.copy();mat.name=rule['name'];bs=next(n for n in mat.node_tree.nodes if n.type=='BSDF_PRINCIPLED')
        if 'roughness' in rule:
            for link in list(bs.inputs['Roughness'].links):mat.node_tree.links.remove(link)
            bs.inputs['Roughness'].default_value=rule['roughness']
        mat['pipeline_normal_strength']=rule.get('normal_strength',.5)
        for node in mat.node_tree.nodes:
            if node.type=='NORMAL_MAP':node.inputs['Strength'].default_value=rule.get('normal_strength',.5)
        ob.data.materials.append(mat);indices.append(len(ob.data.materials)-1)
    uv=ob.data.uv_layers.active
    for face in ob.data.polygons:
        point=sum((uv.data[i].uv for i in face.loop_indices),Vector((0,0)))/len(face.loop_indices)
        selected=label[min(image.size[1]-1,int((point.y%1)*image.size[1])),min(image.size[0]-1,int((point.x%1)*image.size[0]))]
        face.material_index=indices[selected]
    return {'method':'UV-preserving HSV-selected albedo edits with independent PBR material regions','regions':audit}
