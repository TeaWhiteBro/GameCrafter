"""Bounded terrain resampling; the caller supplies independent surface probes."""
import math

def grid(extent,step,height):
    n=math.ceil(extent/step)
    vs=[((i/n-.5)*extent,(j/n-.5)*extent,height((i/n-.5)*extent,(j/n-.5)*extent)) for j in range(n+1) for i in range(n+1)]
    fs=[(j*(n+1)+i,j*(n+1)+i+1,(j+1)*(n+1)+i+1,(j+1)*(n+1)+i) for j in range(n) for i in range(n)]
    return vs,fs,extent/n

def refine(extent,initial_step,min_step,height,evaluate,tolerance=.18):
    if not 0<min_step<=initial_step<=extent:raise ValueError('Invalid bounded terrain sampling resolution')
    attempts=[];step=initial_step
    for _ in range(8):
        vs,fs,effective=grid(extent,step,height)
        errors=sorted(evaluate(vs,fs))
        if not errors or any(not math.isfinite(v) or v<0 for v in errors):raise ValueError('Terrain probes need complete finite surface measurements')
        p95=errors[min(len(errors)-1,int(len(errors)*.95))]
        attempts.append({'step_m':effective,'vertices':len(vs),'samples':len(errors),'p95_error_m':p95,'max_error_m':errors[-1]})
        if p95<=tolerance:return vs,fs,{'passed':True,'attempts':attempts,'p95_error_m':p95,'grid_m':effective}
        if step<=min_step+1e-9:break
        step=max(min_step,step*.65)
    return vs,fs,{'passed':False,'attempts':attempts,'p95_error_m':p95,'grid_m':effective}
