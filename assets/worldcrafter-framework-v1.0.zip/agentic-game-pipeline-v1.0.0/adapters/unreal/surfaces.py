"""PBR surface families. Image sources and appearance parameters live in the job."""
import unreal as u, math
from foliage_wind import SWAY_X_CM, SWAY_Y_CM, FOLIAGE_WEIGHT

def build(name,data,api,texture_library):
    node,wire,output,tex,create,save,prop=[api[k] for k in ['node','wire','output','tex','create','save','prop']]
    ML=u.MaterialEditingLibrary
    m=create(name,api['BASE']+'/Materials',u.Material,u.MaterialFactoryNew())
    for expression in list(ML.get_material_expressions(m)):ML.delete_material_expression(m,expression)
    family=data['surface'];world=family in ['layered_ground','masonry','metal'] or (family=='pbr' and data.get('triplanar',True));prop(m,'tangent_space_normal',not world)
    def nd(cls,**kw):return node(m,cls,**kw)
    def c(x):return nd(u.MaterialExpressionConstant,r=x)
    def v(x):return nd(u.MaterialExpressionConstant3Vector,constant=u.LinearColor(*x,1))
    def mul(a,b):
        q=nd(u.MaterialExpressionMultiply);wire(a,'',q,'A');wire(b,'',q,'B');return q
    def add(a,b):
        q=nd(u.MaterialExpressionAdd);wire(a,'',q,'A');wire(b,'',q,'B');return q
    def lerp(a,b,w):
        q=nd(u.MaterialExpressionLinearInterpolate);wire(a,'',q,'A');wire(b,'',q,'B');wire(w,'',q,'Alpha');return q
    def mask(a,channel):
        q=nd(u.MaterialExpressionComponentMask,**{x.lower():x in channel for x in 'RGBA'});wire(a,'',q,'Input');return q
    def custom(code,inputs,kind=u.CustomMaterialOutputType.CMOT_FLOAT3):
        q=nd(u.MaterialExpressionCustom);q.set_editor_property('code',code);q.set_editor_property('output_type',kind)
        entries=[]
        for k in inputs:
            entry=u.CustomInput();entry.set_editor_property('input_name',k);entries.append(entry)
        q.set_editor_property('inputs',entries)
        for k,value in inputs.items():wire(value,'',q,k)
        return q
    def out(n,p,channel=''):output(n,channel,p)
    pos=nd(u.MaterialExpressionWorldPosition);normal=nd(u.MaterialExpressionVertexNormalWS);vc=nd(u.MaterialExpressionVertexColor)
    def uv(scale,angle=0):
        return custom(f'return float2(P.x*{math.cos(angle)}-P.y*{math.sin(angle)},P.x*{math.sin(angle)}+P.y*{math.cos(angle)})/{float(scale)};',{'P':pos},u.CustomMaterialOutputType.CMOT_FLOAT2)
    def sample(path,key,kind='base',coord=None,triplanar=False,scale=180):
        tx=tex(path,'T_'+name+'_'+key,normal=kind=='normal',linear=kind in ['roughness','orm','alpha','metallic','ao','height'],flip=data.get('normal_opengl',False) and kind=='normal')
        if triplanar:
            obj=nd(u.MaterialExpressionTextureObject,texture=tx);sm=nd(u.MaterialExpressionMaterialFunctionCall);sm.set_material_function(u.load_asset('/Engine/Functions/Engine_MaterialFunctions01/Texturing/'+('WorldAlignedNormal' if kind=='normal' else 'WorldAlignedTexture')))
            wire(obj,'',sm,'TextureObject');wire(v([scale]*3),'',sm,'TextureSize')
            # Return through a reroute because function outputs have named pins.
            route=nd(u.MaterialExpressionReroute);wire(sm,'XYZ Texture',route,'Input');return route
        sm=nd(u.MaterialExpressionTextureSample,texture=tx);sm.set_editor_property('sampler_type',u.MaterialSamplerType.SAMPLERTYPE_NORMAL if kind=='normal' else u.MaterialSamplerType.SAMPLERTYPE_LINEAR_COLOR if kind in ['roughness','orm','alpha','metallic','ao','height'] else u.MaterialSamplerType.SAMPLERTYPE_COLOR)
        if coord:wire(coord,'',sm,'UVs')
        return sm
    def layer(key,settings):
        textures=texture_library[settings['texture_set']];coord=uv(settings.get('scale_cm',220),settings.get('rotation',0))
        tri=data.get('triplanar',False);scale=settings.get('scale_cm',220)
        color=sample(textures['base'],key+'_base',coord=coord,triplanar=tri,scale=scale);color=mul(color,v(settings.get('tint',[1,1,1])))
        if settings.get('desaturate'):
            color=custom('float l=dot(C,float3(.2126,.7152,.0722));return lerp(C,l.xxx,S);',{'C':color,'S':c(settings['desaturate'])})
        nn=sample(textures['normal'],key+'_normal','normal',coord,triplanar=tri,scale=scale)
        rough=mask(sample(textures['roughness'],key+'_rough','roughness',coord,triplanar=tri,scale=scale),'R')
        return color,nn,rough
    if family=='layered_ground':
        sets=data['layers'];a=layer('soil',sets[0]);b=layer('rock',sets[1]);d=layer('moss',sets[2]);rw=mask(vc,'R');mw=mask(vc,'G');wet=mask(vc,'B')
        co=lerp(lerp(a[0],b[0],rw),d[0],mw);co=mul(co,lerp(c(1.06),c(.79),wet))
        out(co,u.MaterialProperty.MP_BASE_COLOR)
        nn=lerp(lerp(a[1],b[1],rw),d[1],mw)
        normal_code='return normalize(lerp(V,N,.45));' if data.get('triplanar',False) else 'return normalize(V+float3(N.xy*.24,0));'
        out(custom(normal_code,{'V':normal,'N':nn}),u.MaterialProperty.MP_NORMAL)
        rough=lerp(lerp(a[2],b[2],rw),d[2],mw);out(lerp(add(c(.38),mul(rough,c(.37))),c(.31),wet),u.MaterialProperty.MP_ROUGHNESS)
    elif family=='masonry':
        textures=data.get('textures') or texture_library[data['texture_set']];scale=data.get('scale_cm',180)
        co=sample(textures['base'],'base',triplanar=True,scale=scale)
        co=custom('float l=dot(C,float3(.2126,.7152,.0722));return lerp(C,l.xxx,S);',{'C':co,'S':c(data.get('desaturate',.50))})
        co=mul(co,v(data.get('tint',[1.15,1.18,1.12])));co=mul(co,lerp(c(.87),c(1.09),mask(vc,'R')))
        if data.get('macro_variation_strength'):
            co=custom('float w=.5+.22*sin(P.x*.0031+sin(P.y*.0043))+.18*sin(P.y*.0061+P.z*.008);return C*lerp(1.,.70+w*.42,S);',{'C':co,'P':pos,'S':c(data['macro_variation_strength'])})
        weather=custom('float p=sin(P.x*.008+sin(P.y*.010))+sin(P.y*.006+P.z*.011)+.35*sin(P.x*.049+P.y*.023);return saturate(G*(.75+p*.32));',{'P':pos,'G':mask(vc,'G')},u.CustomMaterialOutputType.CMOT_FLOAT1)
        if data.get('weather_texture_set'):
            moss=texture_library[data['weather_texture_set']]
            moss_color=sample(moss['base'],'weather_base',triplanar=True,scale=110)
            moss_color=mul(moss_color,v(data.get('weather_tint',[.78,.91,.68])))
        else:moss_color=mul(co,v([.40,.62,.29]))
        co=lerp(co,moss_color,mul(weather,c(.80)))
        out(co,u.MaterialProperty.MP_BASE_COLOR)
        nn=sample(textures['normal'],'normal','normal',triplanar=True,scale=scale)
        out(custom('return normalize(lerp(V,N,S));',{'V':normal,'N':nn,'S':c(data.get('normal_strength',.25))}),u.MaterialProperty.MP_NORMAL)
        rr=mask(sample(textures['roughness'],'rough','roughness',triplanar=True,scale=scale),'R');out(add(c(.36),mul(rr,c(.32))),u.MaterialProperty.MP_ROUGHNESS)
    elif family=='pbr':
        textures=data.get('textures') or texture_library[data['texture_set']];scale=data.get('scale_cm',200);tri=data.get('triplanar',True)
        coord=None if tri else uv(scale,data.get('rotation',0))
        co=sample(textures['base'],'base',coord=coord,triplanar=tri,scale=scale)
        if data.get('paint_color'):
            # Opaque paint replaces wood hue, while measured grain and matched
            # roughness/normal maps retain the substrate's surface structure.
            co=custom('float l=dot(C,float3(.2126,.7152,.0722));return Paint*(1.+D*(2.*l-1.));',
                {'C':co,'Paint':v(data['paint_color']),'D':c(data.get('paint_detail',.16))})
        if data.get('desaturate'):co=custom('float l=dot(C,float3(.2126,.7152,.0722));return lerp(C,l.xxx,S);',{'C':co,'S':c(data['desaturate'])})
        co=mul(co,v(data.get('tint',[1,1,1])))
        if data.get('vertex_tone_strength'):
            co=mul(co,custom('return lerp(1.,clamp(R,.45,1.4),S);',{'R':mask(vc,'R'),'S':c(data['vertex_tone_strength'])},u.CustomMaterialOutputType.CMOT_FLOAT1))
        wet=None
        if data.get('wetness',0)>0:
            # Surface response, not a transparent decal or extra geometry. XY
            # world coordinates make adjacent material batches agree at seams.
            wet=custom('float2 q=P.xy/(Scale*100.); float f=.46+.22*sin(q.x+1.1*sin(q.y*.71))+.20*sin(q.y*1.37+.8*sin(q.x*.53))+.10*sin(q.x*2.93-q.y*2.11); return W*smoothstep(.56,.80,f)*smoothstep(.72,.96,N.z);',
                {'P':pos,'N':normal,'Scale':c(data.get('wetness_scale_m',2.5)),'W':c(data['wetness'])},u.CustomMaterialOutputType.CMOT_FLOAT1)
        if data.get('wetness_zones'):
            from surface_wetness import shader
            wet=custom(shader(data['wetness_zones']),{'P':pos,'N':normal,'Base':wet if wet is not None else c(0)},u.CustomMaterialOutputType.CMOT_FLOAT1)
        if wet is not None:co=mul(co,lerp(c(1),c(.60),wet))
        out(co,u.MaterialProperty.MP_BASE_COLOR)
        nn=sample(textures['normal'],'normal','normal',coord,triplanar=tri,scale=scale)
        strength=c(data.get('normal_strength',.5))
        if wet is not None:strength=mul(strength,lerp(c(1),c(.4),wet))
        out(custom('return normalize(lerp(V,N,S));',{'V':normal if tri else v([0,0,1]),'N':nn,'S':strength}),u.MaterialProperty.MP_NORMAL)
        rr=mask(sample(textures['roughness'],'rough','roughness',coord,triplanar=tri,scale=scale),'R')
        response=custom('return clamp(R*S+B,.06,.98);',{'R':rr,'S':c(data.get('roughness_scale',1)),'B':c(data.get('roughness_bias',0))},u.CustomMaterialOutputType.CMOT_FLOAT1)
        if wet is not None:response=lerp(response,c(.13),wet)
        out(response,u.MaterialProperty.MP_ROUGHNESS)
        if 'metallic' in textures:metal=mask(sample(textures['metallic'],'metal','metallic',coord,triplanar=tri,scale=scale),'R')
        else:metal=c(data.get('metallic',0))
        out(metal,u.MaterialProperty.MP_METALLIC)
        if 'ao' in textures:out(mask(sample(textures['ao'],'ao','ao',coord,triplanar=tri,scale=scale),'R'),u.MaterialProperty.MP_AMBIENT_OCCLUSION)
    elif family=='metal':
        patina=custom('return saturate(.48+.22*sin(P.x*.018+sin(P.z*.036))+.27*sin(P.y*.021+P.z*.013));',{'P':pos},u.CustomMaterialOutputType.CMOT_FLOAT1)
        out(lerp(v(data.get('color',[.20,.10,.038])),v(data.get('patina',[.065,.19,.16])),patina),u.MaterialProperty.MP_BASE_COLOR)
        out(lerp(c(.36),c(.67),patina),u.MaterialProperty.MP_ROUGHNESS);out(c(.82),u.MaterialProperty.MP_METALLIC)
    elif family in ['scan','foliage']:
        textures=data['textures'];co=sample(textures['base'],'base')
        if data.get('desaturate'):co=custom('float l=dot(C,float3(.2126,.7152,.0722));return lerp(C,l.xxx,S);',{'C':co,'S':c(data['desaturate'])})
        co=mul(co,v(data.get('tint',[1,1,1])));out(co,u.MaterialProperty.MP_BASE_COLOR)
        if 'normal' in textures:
            nn=sample(textures['normal'],'normal','normal');out(lerp(v([0,0,1]),nn,c(data.get('normal_strength',.65))),u.MaterialProperty.MP_NORMAL)
        if 'roughness' in textures:rr=mask(sample(textures['roughness'],'roughness','roughness'),'R')
        elif 'orm' in textures:rr=mask(sample(textures['orm'],'orm','orm'),'G')
        else:rr=c(data.get('roughness',.65))
        out(add(c(data.get('roughness_bias',.26)),mul(rr,c(data.get('roughness_scale',.43)))),u.MaterialProperty.MP_ROUGHNESS)
        if 'metallic' in textures:out(mask(sample(textures['metallic'],'metallic','metallic'),'R'),u.MaterialProperty.MP_METALLIC)
        elif 'orm' in textures:out(mask(sample(textures['orm'],'metallic','orm'),'B'),u.MaterialProperty.MP_METALLIC)
        else:out(c(data.get('metallic',0)),u.MaterialProperty.MP_METALLIC)
        if 'emissive' in textures:out(mul(sample(textures['emissive'],'emissive'),c(data.get('emissive_strength',1))),u.MaterialProperty.MP_EMISSIVE_COLOR)
        if 'ao' in textures:out(mask(sample(textures['ao'],'ao','ao'),'R'),u.MaterialProperty.MP_AMBIENT_OCCLUSION)
        if family=='foliage':
            prop(m,'two_sided',True);prop(m,'blend_mode',u.BlendMode.BLEND_MASKED);prop(m,'shading_model',u.MaterialShadingModel.MSM_TWO_SIDED_FOLIAGE)
            out(mask(sample(textures['alpha'],'alpha','alpha'),'R'),u.MaterialProperty.MP_OPACITY_MASK);out(mul(co,c(.4)),u.MaterialProperty.MP_SUBSURFACE_COLOR)
        elif data.get('thin_leaf_subsurface'):
            prop(m,'two_sided',True);prop(m,'shading_model',u.MaterialShadingModel.MSM_TWO_SIDED_FOLIAGE)
            out(mul(co,c(data.get('subsurface_strength',.4))),u.MaterialProperty.MP_SUBSURFACE_COLOR)
    elif family=='botanical':
        prop(m,'two_sided',True);prop(m,'shading_model',u.MaterialShadingModel.MSM_TWO_SIDED_FOLIAGE)
        co=v(data.get('color',[.8,.4,.6]));out(co,u.MaterialProperty.MP_BASE_COLOR)
        out(mul(co,c(.48)),u.MaterialProperty.MP_SUBSURFACE_COLOR);out(c(.68),u.MaterialProperty.MP_ROUGHNESS)
    elif family=='grass':
        prop(m,'two_sided',True);prop(m,'shading_model',u.MaterialShadingModel.MSM_TWO_SIDED_FOLIAGE)
        co=mul(v(data.get('color',[.07,.12,.038])),lerp(c(.46),c(1.13),mask(vc,'R')));out(co,u.MaterialProperty.MP_BASE_COLOR);out(mul(co,c(.5)),u.MaterialProperty.MP_SUBSURFACE_COLOR);out(c(.65),u.MaterialProperty.MP_ROUGHNESS)
    if family in ['foliage','grass','botanical']:
        time=nd(u.MaterialExpressionTime)
        weight=mask(vc,'R') if family=='grass' else c(FOLIAGE_WEIGHT)
        wind=custom(f'float a=sin(T*1.4+P.x*.018+P.y*.011);return float3(a*{SWAY_X_CM},sin(T*1.1+P.y*.012)*{SWAY_Y_CM},0)*W;',{'P':pos,'T':time,'W':weight})
        out(wind,u.MaterialProperty.MP_WORLD_POSITION_OFFSET)
    out(c(.32),u.MaterialProperty.MP_SPECULAR)
    ML.recompile_material(m);save(m);return m
